<?php if (isset($component)) { $__componentOriginalce72fc9e31427f1cb51ea35d51d72257 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce72fc9e31427f1cb51ea35d51d72257 = $attributes; } ?>
<?php $component = App\View\Components\TypingApp::resolve(['role' => 'student','title' => 'งานที่ได้รับ - ระบบวิชาพิมพ์หนังสือราชการ 1'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('typing-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TypingApp::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <!-- Page Header -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
        <div>
            <h1 class="text-2xl md:text-3xl font-bold text-gray-800">
                <i class="fas fa-clipboard-list text-primary-500 mr-2"></i>
                งานที่ได้รับ
            </h1>
            <p class="text-gray-500 mt-1">ดูรายการงานทั้งหมดที่คุณได้รับมอบหมาย</p>
        </div>
        <div class="flex items-center gap-3">
            <select class="input py-2">
                <option value="">สถานะทั้งหมด</option>
                <option value="pending">รอส่งงาน</option>
                <option value="submitted">ส่งแล้ว</option>
                <option value="graded">ให้คะแนนแล้ว</option>
            </select>
        </div>
    </div>
    
    <!-- Stats Overview -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div class="card p-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-primary-100 flex items-center justify-center">
                    <i class="fas fa-list-check text-primary-600"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-800"><?php echo e($totalAssignments); ?></p>
                    <p class="text-xs text-gray-500">งานทั้งหมด</p>
                </div>
            </div>
        </div>
        <div class="card p-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                    <i class="fas fa-clock text-amber-600"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-800"><?php echo e(max(0, $pendingCount)); ?></p>
                    <p class="text-xs text-gray-500">รอส่งงาน</p>
                </div>
            </div>
        </div>
        <div class="card p-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                    <i class="fas fa-paper-plane text-blue-600"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-800"><?php echo e($waitingGrade); ?></p>
                    <p class="text-xs text-gray-500">รอตรวจ</p>
                </div>
            </div>
        </div>
        <div class="card p-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-secondary-100 flex items-center justify-center">
                    <i class="fas fa-check-circle text-secondary-600"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-800"><?php echo e($gradedCount); ?></p>
                    <p class="text-xs text-gray-500">ให้คะแนนแล้ว</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Assignments List -->
    <div class="space-y-4">
        <?php $__empty_1 = true; $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $submission = $assignment->submissions->first();
                $status = 'pending';
                if ($submission) {
                    $status = $submission->score !== null ? 'graded' : 'submitted';
                }
                
                // Determine styling based on status and urgency
                $isExpired = $status == 'pending' && $assignment->due_date && now()->greaterThan($assignment->due_date);
                $isUrgent = !$isExpired && $status == 'pending' && $assignment->due_date && $assignment->due_date->isFuture() && $assignment->due_date->diffInDays(now()) <= 2;
                
                if ($status == 'graded') {
                    $borderColor = 'border-secondary-500';
                    $iconBg = 'bg-gradient-to-br from-secondary-500 to-secondary-600';
                    $icon = 'fa-check-circle';
                    $statusBadge = '<span class="badge-secondary">ให้คะแนนแล้ว</span>';
                } elseif ($status == 'submitted') {
                    $borderColor = 'border-blue-500';
                    $iconBg = 'bg-gradient-to-br from-blue-500 to-blue-600';
                    $icon = 'fa-hourglass-half';
                    $statusBadge = '<span class="badge-primary">รอตรวจ</span>';
                } elseif ($isExpired) {
                    $borderColor = 'border-gray-400';
                    $iconBg = 'bg-gradient-to-br from-gray-400 to-gray-500';
                    $icon = 'fa-lock';
                    $statusBadge = '<span class="px-2 py-1 rounded text-xs font-semibold bg-gray-100 text-gray-600 border border-gray-200">หมดเวลาส่ง</span>';
                } elseif ($isUrgent) {
                    $borderColor = 'border-red-500';
                    $iconBg = 'bg-gradient-to-br from-red-500 to-red-600';
                    $icon = 'fa-fire';
                    $statusBadge = '<span class="badge-danger"><i class="fas fa-exclamation-triangle mr-1"></i>ด่วน!</span>';
                } else {
                    $borderColor = 'border-amber-500';
                    $iconBg = 'bg-gradient-to-br from-amber-500 to-orange-500';
                    $icon = 'fa-file-alt';
                    $statusBadge = '<span class="badge-warning">เปิดรับงาน</span>';
                }
            ?>

            <div class="card p-0 overflow-hidden border-l-4 <?php echo e($borderColor); ?> <?php echo e($isExpired ? 'opacity-75 grayscale-[0.5]' : ''); ?>">
                <div class="p-5">
                    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                        <div class="flex items-start gap-4">
                            <div class="w-14 h-14 rounded-xl <?php echo e($iconBg); ?> flex items-center justify-center flex-shrink-0 shadow-lg">
                                <i class="fas <?php echo e($icon); ?> text-white text-xl"></i>
                            </div>
                            <div>
                                <div class="flex flex-wrap items-center gap-2 mb-1">
                                    <h3 class="text-lg font-semibold text-gray-800"><?php echo e($assignment->title); ?></h3>
                                    <?php echo $statusBadge; ?>

                                </div>
                                <p class="text-sm text-gray-500 mb-2 truncate max-w-md"><?php echo e(Str::limit($assignment->content, 80)); ?></p>
                                <div class="flex flex-wrap items-center gap-4 text-sm">
                                    <span class="text-gray-500">
                                        <i class="fas fa-star mr-1"></i>
                                        คะแนนเต็ม: <?php echo e($assignment->max_score); ?>

                                    </span>
                                    
                                    <?php if($status == 'graded'): ?>
                                        <span class="text-secondary-600 font-semibold">
                                            <i class="fas fa-check mr-1"></i>
                                            คะแนนที่ได้: <?php echo e($submission->score); ?>

                                        </span>
                                    <?php elseif($status == 'submitted'): ?>
                                        <span class="text-blue-600">
                                            <i class="fas fa-clock mr-1"></i>
                                            ส่งเมื่อ: <?php echo e($submission->created_at->format('d/m/Y')); ?>

                                        </span>
                                    <?php elseif($assignment->due_date): ?>
                                        <span class="<?php echo e($isUrgent ? 'text-red-600 font-medium' : ($isExpired ? 'text-red-500 font-medium' : 'text-gray-500')); ?>">
                                            <i class="fas fa-calendar mr-1"></i>
                                            <?php echo e($isExpired ? 'หมดเขตเมื่อ:' : 'ครบกำหนด:'); ?> <?php echo e($assignment->due_date->format('d/m/Y H:i')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="flex items-center gap-2 md:flex-shrink-0">
                            
                            <?php if($status == 'pending'): ?>
                                <a href="#" class="btn-outline py-2 <?php echo e($isExpired ? 'opacity-50 cursor-not-allowed pointer-events-none' : ''); ?>">
                                    <i class="fas fa-eye mr-1"></i>
                                    รายละเอียด
                                </a>
                                <?php if($isExpired): ?>
                                    <button disabled class="px-4 py-2 bg-gray-300 text-gray-500 rounded-lg cursor-not-allowed font-medium text-sm flex items-center">
                                        <i class="fas fa-lock mr-2"></i>
                                        ปิดรับแล้ว
                                    </button>
                                <?php elseif($assignment->submission_type === 'file'): ?>
                                    <a href="<?php echo e(route('typing.student.upload', $assignment->id)); ?>" class="btn-primary py-2">
                                        <i class="fas fa-file-upload mr-1"></i>
                                        อัปโหลดไฟล์
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('typing.student.practice', $assignment->id)); ?>" class="btn-primary py-2">
                                        <i class="fas fa-keyboard mr-1"></i>
                                        เริ่มพิมพ์
                                    </a>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="<?php echo e(route('typing.student.submissions.show', $submission->id)); ?>" class="btn-ghost py-2">
                                    <i class="fas fa-eye mr-1"></i>
                                    ดูผลงาน
                                </a>
                                <?php if($status == 'graded'): ?>
                                    <a href="#" class="btn-outline py-2">
                                        <i class="fas fa-comment mr-1"></i>
                                        Feedback
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center py-12 bg-white rounded-xl border border-dashed border-gray-300">
                <div class="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-clipboard-check text-gray-300 text-3xl"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900">ไม่มีงานที่ได้รับมอบหมาย</h3>
                <p class="text-gray-500">คุณไม่มีงานที่ต้องทำในขณะนี้</p>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Pagination -->
    <div class="flex justify-center mt-8">
        <nav class="flex items-center gap-1">
            <button class="p-2 rounded-lg text-gray-400 hover:bg-gray-100">
                <i class="fas fa-chevron-left"></i>
            </button>
            <button class="w-10 h-10 rounded-lg bg-primary-500 text-white font-medium">1</button>
            <button class="w-10 h-10 rounded-lg text-gray-600 hover:bg-gray-100">2</button>
            <button class="w-10 h-10 rounded-lg text-gray-600 hover:bg-gray-100">3</button>
            <button class="p-2 rounded-lg text-gray-600 hover:bg-gray-100">
                <i class="fas fa-chevron-right"></i>
            </button>
        </nav>
    </div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce72fc9e31427f1cb51ea35d51d72257)): ?>
<?php $attributes = $__attributesOriginalce72fc9e31427f1cb51ea35d51d72257; ?>
<?php unset($__attributesOriginalce72fc9e31427f1cb51ea35d51d72257); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce72fc9e31427f1cb51ea35d51d72257)): ?>
<?php $component = $__componentOriginalce72fc9e31427f1cb51ea35d51d72257; ?>
<?php unset($__componentOriginalce72fc9e31427f1cb51ea35d51d72257); ?>
<?php endif; ?>
<?php /**PATH C:\official-system\resources\views/typing/student/assignments.blade.php ENDPATH**/ ?>