<?php if (isset($component)) { $__componentOriginalce72fc9e31427f1cb51ea35d51d72257 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce72fc9e31427f1cb51ea35d51d72257 = $attributes; } ?>
<?php $component = App\View\Components\TypingApp::resolve(['role' => 'student','title' => 'งานที่ส่งแล้ว - ระบบวิชาพิมพ์หนังสือราชการ 1'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('typing-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TypingApp::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <!-- Page Header -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
        <div>
            <h1 class="text-2xl md:text-3xl font-bold text-gray-800">
                <i class="fas fa-paper-plane text-primary-500 mr-2"></i>
                งานที่ส่งแล้ว
            </h1>
            <p class="text-gray-500 mt-1">ประวัติการส่งงานทั้งหมดของคุณ</p>
        </div>
        <div class="flex items-center gap-3">
            <select class="input py-2">
                <option value="">ทุกสถานะ</option>
                <option value="pending">รอตรวจ</option>
                <option value="graded">ตรวจแล้ว</option>
            </select>
        </div>
    </div>
    
    <!-- Submissions Table -->
    <div class="card">
        <div class="overflow-x-auto w-full">
            <table class="table">
                <thead>
                    <tr>
                        <th>งาน</th>
                        <th>วันที่ส่ง</th>
                        <th>ไฟล์ที่ส่ง</th>
                        <th>สถานะ</th>
                        <th>คะแนน</th>
                        <th>การดำเนินการ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                                    <i class="fas fa-file-alt text-blue-600"></i>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-800"><?php echo e($submission->assignment->title); ?></p>
                                    <p class="text-xs text-gray-500">คะแนนเต็ม <?php echo e($submission->assignment->max_score); ?></p>
                                </div>
                            </div>
                        </td>
                        <td>
                            <p class="text-gray-800"><?php echo e($submission->created_at->format('d/m/Y')); ?></p>
                            <p class="text-xs text-gray-500"><?php echo e($submission->created_at->format('H:i น.')); ?></p>
                        </td>
                        <td>
                            <div class="flex flex-col">
                                <span class="text-sm font-medium text-gray-700">WPM: <?php echo e($submission->wpm); ?></span>
                                <span class="text-xs text-gray-500">ความแม่นยำ: <?php echo e($submission->accuracy); ?>%</span>
                            </div>
                        </td>
                        <td>
                            <?php if($submission->score !== null): ?>
                                <span class="badge-secondary">ตรวจแล้ว</span>
                            <?php else: ?>
                                <span class="badge-warning">รอตรวจ</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($submission->score !== null): ?>
                                <span class="text-lg font-bold text-secondary-600"><?php echo e($submission->score); ?></span>
                                <span class="text-gray-500">/<?php echo e($submission->assignment->max_score); ?></span>
                            <?php else: ?>
                                <span class="text-gray-400">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('typing.student.submissions.show', $submission->id)); ?>" class="btn-ghost text-sm inline-flex items-center">
                                <i class="fas fa-eye mr-1"></i>
                                ดู
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-8 text-gray-500">
                            ยังไม่มีประวัติการส่งงาน
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <div class="flex justify-between items-center mt-6 pt-6 border-t border-gray-100">
            <p class="text-sm text-gray-500">แสดง <?php echo e($submissions->firstItem() ?? 0); ?>-<?php echo e($submissions->lastItem() ?? 0); ?> จาก <?php echo e($submissions->total()); ?> รายการ</p>
            <?php echo e($submissions->links()); ?>

        </div>
    </div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce72fc9e31427f1cb51ea35d51d72257)): ?>
<?php $attributes = $__attributesOriginalce72fc9e31427f1cb51ea35d51d72257; ?>
<?php unset($__attributesOriginalce72fc9e31427f1cb51ea35d51d72257); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce72fc9e31427f1cb51ea35d51d72257)): ?>
<?php $component = $__componentOriginalce72fc9e31427f1cb51ea35d51d72257; ?>
<?php unset($__componentOriginalce72fc9e31427f1cb51ea35d51d72257); ?>
<?php endif; ?>
<?php /**PATH C:\official-system\resources\views/typing/student/submissions.blade.php ENDPATH**/ ?>