<?php if (isset($component)) { $__componentOriginalce72fc9e31427f1cb51ea35d51d72257 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce72fc9e31427f1cb51ea35d51d72257 = $attributes; } ?>
<?php $component = App\View\Components\TypingApp::resolve(['role' => 'admin','title' => 'แก้ไขบทเรียน'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('typing-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TypingApp::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="space-y-6">
        <!-- Header -->
        <div class="flex items-center justify-between">
            <h1 class="text-2xl font-bold text-gray-800">แก้ไขบทเรียน</h1>
            <a href="<?php echo e(route('typing.admin.assignments.index')); ?>" class="btn-ghost">
                <i class="fas fa-arrow-left mr-2"></i>ย้อนกลับ
            </a>
        </div>

        <!-- Form -->
        <div class="card p-6">
            <form action="<?php echo e(route('typing.admin.assignments.update', $assignment->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <!-- Title -->
                    <div class="col-span-2">
                        <label for="title" class="block text-sm font-medium text-gray-700 mb-1">หัวข้อบทเรียน</label>
                        <input type="text" name="title" id="title" class="form-input w-full" value="<?php echo e(old('title', $assignment->title)); ?>" required>
                    </div>

                    <!-- Type -->
                    <div>
                        <label for="type" class="block text-sm font-medium text-gray-700 mb-1">ประเภทเอกสาร</label>
                        <select name="type" id="type" class="form-select w-full">
                            <option value="internal" <?php echo e($assignment->type == 'internal' ? 'selected' : ''); ?>>หนังสือภายใน (Internal)</option>
                            <option value="external" <?php echo e($assignment->type == 'external' ? 'selected' : ''); ?>>หนังสือภายนอก (External)</option>
                            <option value="command" <?php echo e($assignment->type == 'command' ? 'selected' : ''); ?>>คำสั่ง (Command)</option>
                            <option value="memo" <?php echo e($assignment->type == 'memo' ? 'selected' : ''); ?>>บันทึกข้อความ (Memo)</option>
                        </select>
                    </div>

                    <!-- Difficulty -->
                    <div>
                        <label for="difficulty_level" class="block text-sm font-medium text-gray-700 mb-1">ระดับความยาก (1-5)</label>
                        <input type="number" name="difficulty_level" id="difficulty_level" min="1" max="5" value="<?php echo e(old('difficulty_level', $assignment->difficulty_level)); ?>" class="form-input w-full">
                    </div>

                    <!-- Max Score -->
                    <div>
                        <label for="max_score" class="block text-sm font-medium text-gray-700 mb-1">คะแนนเต็ม</label>
                        <input type="number" name="max_score" id="max_score" value="<?php echo e(old('max_score', $assignment->max_score)); ?>" class="form-input w-full">
                    </div>

                    <!-- Due Date -->
                    <div>
                        <label for="due_date" class="block text-sm font-medium text-gray-700 mb-1">กำหนดส่ง (Optional)</label>
                        <input type="datetime-local" name="due_date" id="due_date" value="<?php echo e($assignment->due_date ? $assignment->due_date->format('Y-m-d\TH:i') : ''); ?>" class="form-input w-full">
                    </div>

                    <!-- Active Status -->
                    <div class="flex items-end pb-2">
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" name="is_active" value="1" <?php echo e($assignment->is_active ? 'checked' : ''); ?> class="form-checkbox text-primary-600 rounded">
                            <span class="text-sm text-gray-700">เปิดใช้งาน</span>
                        </label>
                    </div>
                </div>

                <!-- Content -->
                <div class="mb-6">
                    <label for="content" class="block text-sm font-medium text-gray-700 mb-1">เนื้อหาที่ต้องพิมพ์ (สำหรับโหมดพิมพ์ในระบบ)</label>
                    <textarea name="content" id="content" rows="8" class="form-textarea w-full font-mono text-base"><?php echo e(old('content', $assignment->content)); ?></textarea>
                </div>

                <!-- Master Text for Auto-Grading -->
                <div class="mb-6 p-4 bg-blue-50 rounded-xl border border-blue-200">
                    <label for="master_text" class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-robot text-primary-500 mr-1"></i>
                        ข้อความต้นฉบับ (สำหรับตรวจอัตโนมัติ - งานแนบไฟล์)
                    </label>
                    <textarea name="master_text" id="master_text" rows="10" class="form-textarea w-full font-mono text-base" placeholder="วางข้อความที่ถูกต้องที่นี่...&#10;ระบบจะใช้ข้อความนี้เปรียบเทียบกับไฟล์ .docx ที่นักเรียนส่งมา"><?php echo e(old('master_text', $assignment->master_text)); ?></textarea>
                    <p class="text-xs text-blue-600 mt-2"><i class="fas fa-info-circle mr-1"></i>ถ้างานนี้เป็นประเภท "แนบไฟล์" ระบบจะใช้ข้อความนี้เปรียบเทียบและให้คะแนนอัตโนมัติ</p>
                </div>

                <!-- Hidden submission_type to preserve value -->
                <input type="hidden" name="submission_type" value="<?php echo e($assignment->submission_type ?? 'file'); ?>">

                <div class="flex justify-end gap-3 pt-4 border-t border-gray-100">
                    <a href="<?php echo e(route('typing.admin.assignments.index')); ?>" class="btn-ghost">ยกเลิก</a>
                    <button type="submit" class="btn-primary">
                        <i class="fas fa-save mr-2"></i>บันทึกการแก้ไข
                    </button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce72fc9e31427f1cb51ea35d51d72257)): ?>
<?php $attributes = $__attributesOriginalce72fc9e31427f1cb51ea35d51d72257; ?>
<?php unset($__attributesOriginalce72fc9e31427f1cb51ea35d51d72257); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce72fc9e31427f1cb51ea35d51d72257)): ?>
<?php $component = $__componentOriginalce72fc9e31427f1cb51ea35d51d72257; ?>
<?php unset($__componentOriginalce72fc9e31427f1cb51ea35d51d72257); ?>
<?php endif; ?>
<?php /**PATH C:\official-system\resources\views/typing/admin/assignments/edit.blade.php ENDPATH**/ ?>